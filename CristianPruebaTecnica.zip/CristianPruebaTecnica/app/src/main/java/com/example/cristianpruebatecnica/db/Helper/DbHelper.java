package com.example.cristianpruebatecnica.db.Helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "dogs.db";
    private static final String TABLE_DOGS = "t_dogs";
    private static final String SQL_CREATE_DOGS = "CREATE TABLE " + TABLE_DOGS + "(" +
            "ID INTEGER PRIMARY KEY AUTOINCREMENT,"+
            "BREEDS TEXT NOT NULL"
            +")";
    private static final String DELETE_TABLE =  "DROP TABLE IF EXIST " + DATABASE_NAME;
    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_DOGS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DELETE_TABLE);
        onCreate(db);
    }
}
