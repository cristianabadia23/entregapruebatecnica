package com.example.cristianpruebatecnica.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cristianpruebatecnica.R;
import com.example.cristianpruebatecnica.models.Dog;
import com.example.cristianpruebatecnica.ui.MainActivity2;

import java.util.ArrayList;

public class DogAdapter extends RecyclerView.Adapter<DogAdapter.ViewHolder> {
    @NonNull


    ArrayList<Dog> listdogs;
    Context context;
    public DogAdapter(ArrayList<Dog> listdogs, Context context){
        this.listdogs = listdogs;
        this.context = context;
    }

    @Override
    public DogAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dog,null,false);
        return new DogAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DogAdapter.ViewHolder holder, int position) {
        holder.dogText.setText(listdogs.get(position).getBREEDS());
        Glide.with(this.context).load(listdogs.get(position).getImageURL()).into(holder.dogimage);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MainActivity2.class);
                intent.putExtra("raza",listdogs.get(position).getBREEDS());
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return this.listdogs.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView dogimage;
        TextView dogText;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dogimage = (ImageView) itemView.findViewById(R.id.dogimage);
            dogText = (TextView) itemView.findViewById(R.id.dogtext);
        }
    }
}
