package com.example.cristianpruebatecnica;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cristianpruebatecnica.adapter.DogAdapter;
import com.example.cristianpruebatecnica.db.Helper.DbHelper;
import com.example.cristianpruebatecnica.db.Helper.DogsHelper;
import com.example.cristianpruebatecnica.models.Dog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private static String BASEURL = "https://dog.ceo/api/breeds/list/all";
    private static final String TAG = "AVISO";
    private SQLiteDatabase db;
    private DbHelper dbHelper;
    private static final String TABLE_DOGS = "t_dogs";
    private DogsHelper dh;
    private ArrayList<Dog> dogs;
    private RecyclerView dogsList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dogsList = findViewById(R.id.recyclerID);
        dbHelper = new DbHelper(this);
        db = dbHelper.getWritableDatabase();
        dh = new DogsHelper(this);
        dogs = new ArrayList<Dog>();
        if (db != null){
            Toast.makeText(this,"DB Comprobada",Toast.LENGTH_LONG);
        }
        else{
            Toast.makeText(this,"Error db",Toast.LENGTH_LONG);
        }
        getDogs();
        selectDogs();
        buscarimagenes();
        generateAdapter();
    }

    private void buscarimagenes() {
        OkHttpClient client = new OkHttpClient();
        for (Dog d: dogs) {
            Request request = new Request.Builder()
                    .url("https://dog.ceo/api/breed/" + d.getBREEDS() + "/images/random")
                    .build();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {

                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        final String myResponse = response.body().string();
                        MainActivity.this.runOnUiThread(new Runnable() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void run() {
                                String jsonData = myResponse;
                                JSONObject Jobject = null;
                                try {
                                    Jobject = new JSONObject(jsonData);
                                    String image = Jobject.get("message").toString();
                                    d.setImageURL(image);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        });
                    }
                }
            });
        }
    }

    private void generateAdapter() {
        dogsList.setLayoutManager(new LinearLayoutManager(this));
        DogAdapter adapter = new DogAdapter(dogs,this);
        dogsList.setAdapter(adapter);
    }

    private void selectDogs() {
        SQLiteDatabase db2 = dbHelper.getReadableDatabase();
        Cursor cursor  = db2.rawQuery("SELECT * FROM " + TABLE_DOGS,null);
        Log.i(".+.+. ","consulta");
        while (cursor.moveToNext()){
            dogs.add(new Dog(cursor.getInt(0),cursor.getString(1)));

        }
        db2.close();
        cursor.close();
    }

    private void getDogs() {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASEURL)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String myResponse = response.body().string();
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @RequiresApi(api = Build.VERSION_CODES.N)
                        @Override
                        public void run() {
                            String jsonData = myResponse;
                            JSONObject Jobject = null;
                            try {
                                Jobject = new JSONObject(jsonData);
                                JSONObject dogs = Jobject.getJSONObject("message");
                                dogs.keys().forEachRemaining(x-> dh.insertDog(x));
                                dh.close();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });
                }
            }
        });
    }
}