package com.example.cristianpruebatecnica.models;

public class Dog {
    private int ID;
    private String BREEDS;
    private String imageURL;

    public Dog(int ID, String BREEDS, String imageURL) {
        this.ID = ID;
        this.BREEDS = BREEDS;
        this.imageURL = imageURL;
    }

    public Dog(int ID, String BREEDS) {
        this.ID = ID;
        this.BREEDS = BREEDS;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getBREEDS() {
        return BREEDS;
    }

    public void setBREEDS(String BREEDS) {
        this.BREEDS = BREEDS;
    }



    @Override
    public String toString() {
        return "Dog{" +
                "ID=" + ID +
                ", BREEDS='" + BREEDS + '\'' +
                '}';
    }
}
