package com.example.cristianpruebatecnica.db.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.Nullable;

public class DogsHelper extends DbHelper{

    Context context;
    private static final String TABLE_DOGS = "t_dogs";
    public DogsHelper(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public long insertDog(String BREEDS){
        long id = 0;
        try {
            DbHelper db = new DbHelper(context);
            SQLiteDatabase sqld = db.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("BREEDS",BREEDS);
            id = sqld.insert(TABLE_DOGS,null,values);

        }
        catch (Exception ex){
            ex.toString();
        }
        return id;
    }
}
